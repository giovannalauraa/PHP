<?php

$nome = "Gi! >.<";
$numero = 13;
$aniversario = 13.08;

/**
 * Comentário de várias linhas
 */

 //Comentário

echo 'O nome é: ' .$nome."<br>";
echo 'O número é:' .$numero."<br>";
echo 'A data do aniversário é: ' .$aniversario."<br>";

$n1 = 10;
$n2 = 30;

$soma = $n1 + $n2;
$subtracao = $n1 - $n2;
$multiplicacao = $n1 * $n2;
$divisao = $n1 / $n2;
$resto = 10 % 2;

echo '<br> A soma é: ' .$soma."<br>";
echo 'A subtração é: ' .$subtracao."<br>";
echo 'A multiplicação é: ' .$multiplicacao."<br>";
echo 'A divisão é: ' .$divisao."<br>";

// Verificando se um número é par ou ímpar

if($numero % 2 == 0){
    echo "<br> O número $numero é par <br>";
}else{
    echo "<br> O número $numero é ímpar <br>";
}

// Switch
    $opcao = 1;
    switch($opcao){
        case 1:
            echo "<br> Opcao escolhida 1 <br>";
        break;
        case 2:
            echo "<br> Opção escolhida 2 <br>";
        break;
        default:
            echo "<br> Opção inválida <br>";
    }

//Operador ternário
    $idade = 18;

    echo ($idade>= 18)?"<br> Maior de idade":"<br> Menor de idade";

// Outra opção

/**
* echo "O nome é: $nome <br>";
*echo "O número é: $numero <br>";
*echo "O valor é: $valor <br>";
 */